a = 9
b = 7
c = a/b
print(c)