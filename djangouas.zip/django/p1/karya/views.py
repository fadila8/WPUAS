from turtle import title
from django.shortcuts import render,HttpResponse

# Create your views here.
def satu(request):
    return HttpResponse('Halo')

def home(request):
    context={
        'title':title
    }
    return render(request, 'home.html',context)
def PUISI(request):
    context={
        'title':title
    }
    return render(request, 'PUISI.html',context)
def PANTUN(request):
    context={
        'title':title
    }
    return render(request, 'PANTUN.html',context)
def QUOTES(request):
    context={
        'title':title
    }
    return render(request, 'QUOTES.html',context)
