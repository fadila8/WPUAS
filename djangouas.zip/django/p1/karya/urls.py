from unicodedata import name
from django.urls import path
from . import views

urlpatterns =[
    path('',views.satu,name='satu'),
    path('home',views.home,name='home'),
    path('PUISI',views.PUISI,name='PUISI'),
    path('PANTUN',views.PANTUN,name='PANTUN'),
    path('QUOTES',views.QUOTES,name='QUOTES'),


]